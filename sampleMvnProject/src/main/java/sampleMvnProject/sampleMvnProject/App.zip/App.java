package sampleMvnProject.sampleMvnProject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Hello world!
 *
 */
public class App {

	public static final String SYNONYMS = "synonyms";
	public static final String DIFFERENT = "different";

	public static void main(String[] args) throws IOException {

		FileReader fr = new FileReader("C:\\Users\\km185264\\Downloads\\test.in");
		BufferedReader br = new BufferedReader(fr);
		int i;

		BufferedWriter bw = null;
		File file = new File("C:\\\\Users\\\\km185264\\\\Downloads\\\\test.out");

		if (!file.exists()) {
			file.createNewFile();
		}

		FileWriter fw = new FileWriter(file);
		bw = new BufferedWriter(fw);

		int count = Integer.parseInt(br.readLine());
		HashMap<String, String> map = new HashMap<>();
		while (count > 0) {
			int lines = Integer.parseInt(br.readLine());
			while (lines > 0) {
				String read = br.readLine();
				if (!read.isEmpty())
					map.put(read.split(" ")[0], read.split(" ")[1]);
				// bw.write(map.values());
				lines--;
			}
			int linesCheck = Integer.parseInt(br.readLine());
			while (linesCheck > 0) {
				String read = br.readLine();
				if (!read.isEmpty()) {
					String s1 = read.split(" ")[0];
					String s2 = read.split(" ")[1];
					if (s1.equalsIgnoreCase(s2)) {
						bw.write(SYNONYMS);
						bw.newLine();
					} else if (map.containsKey(s1)) {
						if (map.get(s1).equalsIgnoreCase(s2)) {
							bw.write(SYNONYMS);
							bw.newLine();
						} else if (map.containsKey(map.get(s1)) && map.get(map.get(s1)).equalsIgnoreCase(s2)) {
							bw.write(SYNONYMS);
							bw.newLine();
						} else {
							bw.write(DIFFERENT);
							bw.newLine();
						}
					} else if (map.containsValue(s1)) {
						List<String> list = new ArrayList<>();
						map.entrySet().stream().filter(entry -> s1.equalsIgnoreCase(entry.getValue()) || s1.equalsIgnoreCase(map.get(entry.getValue())))
								.map(Map.Entry::getKey).forEach(list::add);
						if (list.contains(s2)) {
							bw.write(SYNONYMS);
							bw.newLine();
						} else {
							bw.write(DIFFERENT);
							bw.newLine();
						}
					} else {
						bw.write(DIFFERENT);
						bw.newLine();
					}
				}
				linesCheck--;
			}
			count--;
		}
		br.close();
		fr.close();

		bw.close();
		fw.close();

	}
}
